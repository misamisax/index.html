import { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, RefreshCw } from 'lucide-react';
import { BASES, MULTIPLIERS, ALL_SYMBOLS } from './constants';

export default function App() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const convertCode = (code: string) => {
    if (!code.trim()) return null;

    let total = 0;
    let currentCoeff = 0;
    let index = 0;
    const tokens: string[] = [];

    // Tokenization
    while (index < code.length) {
      let matched = false;
      for (const symbol of ALL_SYMBOLS) {
        if (code.toUpperCase().startsWith(symbol.toUpperCase(), index)) {
          tokens.push(symbol);
          index += symbol.length;
          matched = true;
          break;
        }
      }
      if (!matched) {
        index++;
      }
    }

    // Parsing Logic
    for (const token of tokens) {
      const upperToken = token.toUpperCase();
      if (BASES[upperToken] !== undefined) {
        currentCoeff = currentCoeff * 10 + BASES[upperToken];
      } else if (MULTIPLIERS[upperToken] !== undefined) {
        const multiplierValue = MULTIPLIERS[upperToken];
        const coeff = currentCoeff === 0 ? 1 : currentCoeff;
        total += coeff * multiplierValue;
        currentCoeff = 0;
      }
    }

    total += currentCoeff;
    return total;
  };

  useEffect(() => {
    const converted = convertCode(input);
    setResult(converted);
  }, [input]);

  const formattedResult = useMemo(() => {
    if (result === null) return '0';
    return new Intl.NumberFormat().format(result);
  }, [result]);

  return (
    <div className="min-h-screen bg-[#fdfdfc] text-[#1a1a1a] font-sans flex flex-col overflow-x-hidden selection:bg-stone-200">
      {/* Header */}
      <header className="px-6 lg:px-12 py-8 flex justify-between items-center border-b border-stone-100">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-stone-900 rounded-lg flex items-center justify-center">
            <span className="text-white font-mono text-xs">Σ</span>
          </div>
          <h1 className="text-xs font-semibold tracking-[0.25em] uppercase">Cipher Converter</h1>
        </div>
        <div className="hidden sm:block text-[10px] text-stone-400 font-medium tracking-widest uppercase">
          System Active • v1.0.2
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-4xl space-y-16 lg:space-y-24">
          
          {/* Input Section */}
          <div className="space-y-6">
            <div className="flex items-center justify-between px-1">
              <label 
                htmlFor="cipher-input"
                className="text-[11px] font-bold text-stone-400 uppercase tracking-[0.3em]"
              >
                Input Code
              </label>
              <button 
                onClick={() => setInput('')}
                className="p-1 hover:bg-stone-100 rounded-full transition-colors group"
                title="Clear input"
              >
                <RefreshCw className="w-4 h-4 text-stone-300 group-hover:text-stone-900" />
              </button>
            </div>
            <div className="relative group">
              <input
                id="cipher-input"
                ref={inputRef}
                type="text"
                autoFocus
                autoComplete="off"
                spellCheck="false"
                placeholder="---"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="w-full bg-transparent text-6xl md:text-8xl lg:text-9xl font-mono tracking-tighter text-stone-900 border-none outline-none focus:ring-0 p-0 placeholder:text-stone-100 uppercase"
              />
              <div className="absolute -bottom-4 left-0 w-full h-[1px] bg-stone-100 transition-all duration-500 overflow-hidden">
                <motion.div 
                  className="h-full bg-stone-900"
                  animate={{ width: input ? '100%' : '0%' }}
                  transition={{ duration: 0.8, ease: "circOut" }}
                />
              </div>
            </div>
          </div>

          {/* Divider Icon */}
          <div className="flex justify-center">
            <motion.div 
              animate={{ y: [0, 5, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className="w-10 h-10 lg:w-12 lg:h-12 rounded-full border border-stone-200 flex items-center justify-center"
            >
              <ChevronDown className="w-5 h-5 lg:w-6 lg:h-6 text-stone-300" />
            </motion.div>
          </div>

          {/* Result Section */}
          <div className="space-y-6">
            <label className="text-[11px] font-bold text-stone-400 uppercase tracking-[0.3em] px-1">
              Converted Value
            </label>
            <div className="flex items-baseline gap-4 overflow-hidden">
              <AnimatePresence mode="wait">
                <motion.span
                  key={formattedResult}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.2, ease: "easeOut" }}
                  className="text-7xl md:text-8xl lg:text-[10rem] font-extrabold tracking-tighter text-stone-900 leading-none break-all"
                >
                  {formattedResult}
                </motion.span>
              </AnimatePresence>
              <span className="text-xl lg:text-2xl font-medium text-stone-300 uppercase tracking-widest translate-y-[-10%]">
                INT
              </span>
            </div>
          </div>
        </div>
      </main>

      {/* Footer / Legend */}
      <footer className="px-6 lg:px-12 py-12 lg:py-16 bg-[#fafaf9] border-t border-stone-100">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
          
          {/* Digits Legend */}
          <div className="space-y-6">
            <h3 className="text-[10px] font-bold text-stone-400 uppercase tracking-[0.2em]">Digit Mappings</h3>
            <div className="grid grid-cols-5 md:grid-cols-9 gap-3">
              {Object.entries(BASES).map(([char, val]) => (
                <div 
                  key={char} 
                  className="flex flex-col items-center p-3 rounded-xl bg-white border border-stone-100 shadow-[0_2px_4px_rgba(0,0,0,0.02)]"
                >
                  <span className="text-sm font-mono font-bold text-stone-900">{char}</span>
                  <span className="text-[10px] text-stone-400 font-medium">{val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Multipliers Legend */}
          <div className="space-y-6">
            <h3 className="text-[10px] font-bold text-stone-400 uppercase tracking-[0.2em]">Multipliers</h3>
            <div className="grid grid-cols-4 md:grid-cols-7 gap-3">
              {Object.entries(MULTIPLIERS).map(([char, val]) => (
                <div 
                  key={char} 
                  className="flex flex-col items-center p-3 rounded-xl bg-white border border-stone-100 shadow-[0_2px_4px_rgba(0,0,0,0.02)]"
                >
                  <span className="text-sm font-mono font-bold text-stone-900">{char}</span>
                  <span className="text-[10px] text-stone-400 font-medium">
                    {val >= 1000 ? `10${Math.log10(val).toString().replace(/\.0$/, '')}` : val}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>
        
        <div className="mt-16 text-center text-[10px] text-stone-300 font-medium uppercase tracking-[0.3em]">
          Positional Cipher System • Logic Engine v1.0
        </div>
      </footer>
    </div>
  );
}
