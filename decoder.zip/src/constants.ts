/**
 * Conversion rules and mappings for the Cipher Calc system.
 */

export const BASES: Record<string, number> = {
  'A': 1,
  'K': 2,
  'S': 3,
  'T': 4,
  'N': 5,
  'H': 6,
  'M': 7,
  'Y': 8,
  'R': 9,
};

export const MULTIPLIERS: Record<string, number> = {
  'Z': 10000000,
  "Y'": 1000000,
  'X': 100000,
  'W': 10000,
  'V': 1000,
  ':': 100,
  '*': 10,
};

// All symbols identified for tokenization
export const ALL_SYMBOLS = [
  "Y'",
  'A', 'K', 'S', 'T', 'N', 'H', 'M', 'Y', 'R',
  'Z', 'X', 'W', 'V', ':', '*'
].sort((a, b) => b.length - a.length); // Longest first for greedy matching
